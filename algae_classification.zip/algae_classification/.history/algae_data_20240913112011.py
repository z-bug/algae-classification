import os

## 藻类数据
algae_data = {
    "蓝藻门 (Cyanobacteria)": {
        "微囊藻属 (Microcystis)": {
            "特征": [
                "球形细胞，形成不规则群体",
                "细胞被共同的胶质包围",
                "颜色通常为亮绿色或蓝绿色"
            ],
            "生态学意义":[
                "常见于富营养化水体",
                "可产生微囊藻毒素，威胁水生生态系统和人类健康",
                "大量繁殖时可形成水华，影响水质"
            ],
            "图片": ["microcystis_example1.png", "microcystis_example2.png"]
        },
        "惠氏微囊藻 (Microcystis wesenbergii)": {
            "特征": [
                "群体边缘轮廓清晰明显，呈现光滑的外观",
                "胶被较厚，透明，易于观察",
                "细胞在群体中排列较为疏松"
            ],
            "生态学意义":[
                "常见于富营养化水体,是水华形成的重要种类之一",
                "可产生微囊藻毒素，威胁水生生态系统和人类健康",
                "大量繁殖时可形成水华，影响水质"
            ],
            "图片": ["microcystis_wesenbergii_example1.png", "microcystis_wesenbergii_example2.png"]
        },
        "假鱼腥藻属 (Pseudanabaena)": {
            "特征": [
                "丝状体，直或略弯曲",
                "细胞呈圆柱形，长度通常大于宽度",
                "细胞间有明显的缢缩",
                "丝体较细，宽度通常在1-3微米之间",
                "无异形胞和气泡",
                "色素体呈顶生或侧生"
            ],
            "生态学意义": [
                "广泛分布于淡水和海水环境中",
                "某些种类可能产生异味物质，影响水质",
                "在某些水体中可作为水质指标生物"
            ],
            "图片": ["pseudanabaena_example1.png", "pseudanabaena_example2.png"]
        },
        "束丝藻属 (Aphanizomenon)": {
            "特征": [
                "丝状体，直或略弯曲，常成束或散开",
                "细胞呈圆柱形，长度通常等于或略大于宽度",
                "末端细胞略长且呈圆柱形或稍尖",
                "具有异形胞和厚壁孢子",
                "异形胞通常位于丝体中部，远离末端",
                "有气泡，使其能在水中漂浮",
                "颜色通常为淡蓝绿色"
            ],
            "生态学意义": [
            "能固定大气中的氮，对水体氮循环有重要作用",
            "某些种类可产生毒素，如沙索毒素",
            "在温带湖泊中常形成水华，影响水体生态平衡"
        ],
            "图片": ["aphanizomenon_example1.png", "aphanizomenon_example2.png"]
        },
        "浮丝藻 (Planktothrix)": {
            "特征": [
                "丝状体，直线型或略微弯曲",
                "单丝不分枝，细胞宽度一致",
                "细胞呈圆柱形，长度通常小于或等于宽度",
                "颜色多样，包括蓝绿色、红色或褐色",
                "无异形胞"
            ],
            "生态学意义": [
                "适应性强，能在不同光照条件下生存",
                "某些种类可产生微囊藻毒素，威胁水生生态系统",
                "在深水湖泊中可形成深层叶绿素最大值层"
            ],
            "图片": ["planktothrix_example1.png", "planktothrix_example2.png"]
        },
        "长胞藻属 (Dolichospermum)": {
            "特征": [
                "丝状体，通常呈螺旋形或弯曲",
                "细胞呈球形、椭圆形或桶形",
                "细胞连接处有明显的缢缩",
                "具有异形胞和厚壁孢子",
                "异形胞通常位于两个营养细胞之间",
                "有气泡，常成对出现在异形胞两侧",
                "颜色通常为蓝绿色或橄榄绿色"
            ],
            "生态学意义": [
                "能固定大气中的氮，对水体营养循环有重要影响",
                "某些种类可产生神经毒素，如麻痹性贝类毒素",
                "在温带湖泊中常形成水华，影响水质和生态系统平衡"
            ],
            "图片": ["dolichospermum_example1.png", "dolichospermum_example2.png"]
        }
    },
    "绿藻门 (Chlorophyta)": {
        "栅藻属 (Scenedesmus)": {
            "特征": [
                "细胞排列成平面群体",
                "通常由2、4或8个细胞组成",
                "部分种类细胞两端有刺"
            ],
            "生态学意义": [
                "广泛分布于淡水环境中",
                "对水质变化有一定的指示作用",
                "可作为水产养殖的天然饵料"
            ],
            "图片": ["scenedesmus_example1.png", "scenedesmus_example2.png"]
        },
        "空星藻属 (Coelastrum)": {
            "特征": [
                "细胞形成球形或近球形的群体",
                "群体通常由4、8、16、32或64个细胞组成",
                "单个细胞呈球形、卵形或多角形",
                "细胞之间通过短的突起或臂相连",
                "群体大小通常在20-60微米之间",
                "每个细胞含有一个杯状叶绿体，通常有一个焦粒",
                "群体呈现出规则的几何结构",
                "主要生活在淡水环境中"
            ],
            "生态学意义": [
                "广泛分布于淡水环境中，是初级生产者",
                "可作为水质评价的指标生物之一",
                "在水产养殖中可作为鱼类和无脊椎动物的天然饵料"
            ],
            "图片": ["coelastrum_example1.png", "coelastrum_example2.png"]
        },
        "盘星藻属 (Pediastrum)": {
            "特征": [
                "群体呈圆盘状或星形",
                "群体由4到64个（有时更多）细胞组成",
                "边缘细胞通常有1-2个角状突起",
                "内部细胞多为多边形",
                "细胞排列紧密，形成平面群体",
                "每个细胞含有一个叶绿体，有一个焦粒",
                "群体直径通常在30-200微米之间",
                "颜色通常为鲜绿色"
            ],
            "生态学意义": [
                "常见于富营养化水体中，是水体富营养化的指示生物之一",
                "在古生态学研究中可作为环境变化的指标",
                "对水体中磷的循环有一定影响"
            ],
            "图片": ["pediastrum_example1.png", "pediastrum_example2.png"]
        },
        "纤维藻属 (Ankistrodesmus)": {
            "特征": [
                "植物体单细胞，或2、4、8、16个或更多细胞聚集成群",
                "主要浮游生活，罕见附着在基质上",
                "细胞形状多样：纺锤形、针形、弓形、镰形或螺旋形",
                "细胞直或弯曲，自中央向两端渐尖细",
                "末端通常尖锐，罕见钝圆",
                "细胞长度通常在20-100微米之间",
                "宽度通常在2-6微米之间" 
            ],
            
            "图片": ["ankistrodesmus_example1.png", "ankistrodesmus_example2.png"]
        }
    },
    "硅藻门 (Bacillariophyta)": {
        "直链藻属 (Melosira)": {
            "特征": [
                "细胞呈圆柱形，形成长链状群体",
                "细胞通过壳面紧密连接，形成直链",
                "壳面圆形，带面矩形",
                "细胞内含多个盘状叶绿体"
            ],
            "生态学意义": [
                "常见于各类水体中，尤其是在河流和湖泊中",
                "可作为水质评估的指标生物",
                "在水体初级生产力中起重要作用"
            ],
            "图片": ["melosira_example1.png", "melosira_example2.png"]
        },
        "颗粒直链藻极狭变种 (Melosira granulata var. angustissima)": {
            "特征": [
                "细胞呈细长的圆柱形，长度远大于宽度",
                "细胞连接成长链，链条通常呈直线或略微弯曲",
                "壳面上有明显的颗粒状结构",
                "细胞直径通常在2-5微米之间，长度可达20-100微米"
            ],
            "图片": ["melosira_granulata_angustissima_example1.png", "melosira_granulata_angustissima_example2.png"]
        },
        "菱形藻属 (Nitzschia)": {
            "特征": [
                "壳面呈细长的菱形或线形",
                "具有明显的龙骨点",
                "壳面有横向条纹"
            ],
            "图片": ["nitzschia_example1.png", "nitzschia_example2.png"]
        },
        "针杆藻属 (Synedra)": {
            "特征": [
                "细长的线形或针形",
                "单独生活或形成放射状群体",
                "壳面有横向条纹"
            ],
            "图片": ["synedra_example1.png", "synedra_example2.png"]
        },
        "小环藻属 (Cyclotella)": {
            "特征": [
                "圆盘形，壳面圆形",
                "中央区和边缘区明显分界",
                "中央区可能平滑或有点纹",
                "边缘区有放射状条纹",
                "大小通常在5-30微米之间"
            ],
            "图片": ["cyclotella_example1.png", "cyclotella_example2.png"]
        }
    }
}

def generate_html_content(images_folder):
    main_content = "<h1>藻类分类特征整理</h1>"
    toc_content = "<ul>"
    
    for phylum, genera in algae_data.items():
        phylum_id = phylum.split()[0].lower()
        toc_content += f'<li><a href="#{phylum_id}">{phylum}</a><ul>'
        main_content += f'<h2 id="{phylum_id}">{phylum}</h2>'
        
        for genus, details in genera.items():
            genus_id = genus.split()[0].lower()
            toc_content += f'<li><a href="#{genus_id}">{genus}</a></li>'
            main_content += f"""
            <div class="genus" id="{genus_id}">
                <h3>{genus}</h3>
                <div class="genus-content">
                    <div class="features">
                        <h4>特征：</h4>
                        <ul>
                            {"".join(f"<li>{feature}</li>" for feature in details['特征'])}
                        </ul>
                    </div>
                    <div class="ecological-significance">
                        <h4>生态学意义：</h4>
                        <ul>
                            {"".join(f"<li>{significance}</li>" for significance in details['生态学意义'])}
                        </ul>
                    </div>
                </div>
                <div class="image-container">
                    {"".join(f'<img src="{os.path.join("images", img)}" alt="{genus}示例图片 {i+1}">' for i, img in enumerate(details['图片']) if os.path.exists(os.path.join(images_folder, img)))}
                </div>
            </div>
            """
        
        toc_content += '</ul></li>'
    
    toc_content += "</ul>"
    
    return main_content, toc_content

def generate_html(template_path, output_path, images_folder):
    with open(template_path, 'r', encoding='utf-8') as f:
        template = f.read()
    
    main_content, toc_content = generate_html_content(images_folder)
    html_content = template.replace('{main_content}', main_content).replace('{toc_content}', toc_content)
    
    with open(output_path, 'w', encoding='utf-8') as f:
        f.write(html_content)

def check_images(images_folder):
    missing_images = []
    existing_images = []
    for phylum, genera in algae_data.items():
        for genus, details in genera.items():
            for img in details['图片']:
                img_path = os.path.join(images_folder, img)
                if not os.path.exists(img_path):
                    missing_images.append(img)
                else:
                    existing_images.append(img)
    return missing_images, existing_images