import os
from algae_data import generate_html, check_images, algae_data

# 设置路径
current_dir = os.path.dirname(os.path.abspath(__file__))
template_path = os.path.join(current_dir, 'template.html')
output_path = os.path.join(current_dir, 'algae_classification.html')
images_folder = os.path.join(current_dir, 'images')

# 确保 images 文件夹存在
if not os.path.exists(images_folder):
    os.makedirs(images_folder)

# 生成 HTML
generate_html(template_path, output_path, images_folder)
print(f"HTML 文件已生成：{output_path}")



