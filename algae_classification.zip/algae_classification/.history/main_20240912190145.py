import os
from algae_data import generate_html, check_images, algae_data

# 设置路径
current_dir = os.path.dirname(os.path.abspath(__file__))
template_path = os.path.join(current_dir, 'template.html')
output_path = os.path.join(current_dir, 'algae_classification.html')
images_folder = os.path.join(current_dir, 'images')

# 确保 images 文件夹存在
if not os.path.exists(images_folder):
    os.makedirs(images_folder)

# 生成 HTML
generate_html(template_path, output_path, images_folder)
print(f"HTML 文件已生成：{output_path}")

# 检查图片
missing_images, existing_images = check_images(images_folder)

print("\n图片检查结果：")
print(f"images 文件夹的位置：{images_folder}")

if missing_images:
    print("\n以下图片文件缺失：")
    for img in missing_images:
        print(f"- {img}")
else:
    print("\n所有图片文件都已存在。")

print("\n已找到的图片文件：")
for img in existing_images:
    print(f"- {img}")