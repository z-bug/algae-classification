import os
from algae_data import generate_html, check_images

# 设置路径
current_dir = os.path.dirname(os.path.abspath(__file__))
template_path = os.path.join(current_dir, 'template.html')
output_path = os.path.join(current_dir, 'algae_classification.html')
images_folder = os.path.join(current_dir, 'images')

# 确保 images 文件夹存在
if not os.path.exists(images_folder):
    os.makedirs(images_folder)


# 生成 HTML
generate_html(template_path, output_path, images_folder)
print(f"HTML 文件已生成：{output_path}")

def get_all_defined_images():
    defined_images = set()
    for phylum in algae_data.values():
        for genus in phylum.values():
            defined_images.update(genus['图片'])
    return defined_images

def find_extra_images(images_folder, defined_images):
    all_images = set(f for f in os.listdir(images_folder) if f.lower().endswith(('.png', '.jpg', '.jpeg')))
    return all_images - defined_images


# 检查图片
missing_images, existing_images = check_images(images_folder)

print("\n图片检查结果：")
print(f"images 文件夹的位置：{images_folder}")

if missing_images:
    print("\n以下图片文件缺失：")
    for img in missing_images:
        print(f"- {img}")
else:
    print("\n所有图片文件都已存在。")

print("\n已找到的图片文件：")
for img in existing_images:
    print(f"- {img}")

print("\n当前 images 文件夹中的所有文件：")
if os.path.exists(images_folder):
    for file in os.listdir(images_folder):
        print(f"- {file}")
else:
    print("images 文件夹不存在或无法访问")

print("\n如果仍有缺失的图片，请确保：")
print("1. 文件名完全匹配（包括大小写）")
print("2. 文件为 .png 格式")
print("3. 文件直接放在 images 文件夹中，不在子文件夹内")


# 获取所有在数据中定义的图片
defined_images = get_all_defined_images()

# 查找额外的图片
extra_images = find_extra_images(images_folder, defined_images)

if extra_images:
    print("\n在 images 文件夹中发现以下额外的图片文件：")
    for img in sorted(extra_images):
        print(f"- {img}")
    print("\n这些图片可能代表了额外的藻类种类，或者是现有种类的额外图片。")
else:
    print("\nImages 文件夹中没有发现额外的图片文件。")