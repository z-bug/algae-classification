import os
from algae_data import generate_html, check_images, algae_data

def main():
    # 设置路径
    current_dir = os.path.dirname(os.path.abspath(__file__))
    template_path = os.path.join(current_dir, 'template.html')git 
    output_path = os.path.join(current_dir, 'algae_classification.html')
    images_folder = os.path.join(current_dir, 'images')

    # 确保 images 文件夹存在
    os.makedirs(images_folder, exist_ok=True)

    # 生成 HTML
    generate_html(template_path, output_path, images_folder)
    print(f"HTML 文件已生成：{output_path}")

    # 检查图片
    missing_images, existing_images = check_images(images_folder)

    print("\n图片检查结果：")
    print(f"images 文件夹的位置：{images_folder}")

    if missing_images:
        print("\n以下图片文件缺失：")
        for img in missing_images:
            print(f"- {img}")
    else:
        print("\n所有图片文件都已存在。")

    print(f"\n已找到 {len(existing_images)} 个图片文件：")
    for img in existing_images:
        print(f"- {img}")

    # 输出总结
    total_images = len(missing_images) + len(existing_images)
    print(f"\n总结：")
    print(f"总图片数：{total_images}")
    print(f"缺失图片数：{len(missing_images)}")
    print(f"存在图片数：{len(existing_images)}")
    print(f"图片完整率：{len(existing_images) / total_images:.2%}")

if __name__ == "__main__":
    main()